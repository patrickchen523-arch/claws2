# game-analyse 更新记录

---

## V2.5 — 2026-03-20（公司内部发布版）

### 面向推广的结构性改进

**新增：Gameplay Card 模板**
- `entry-templates.md` 新增第四节"Gameplay Card"模板
- 包含主玩法卡和副玩法卡（变体/独立）两套标准模板
- 包含字段来源对照表，明确每个字段从哪个 Phase 产出中提取

**修复：路径系统全面改为相对路径**
- 引入 `${MECHANISM_LIB}` 路径变量，用户在分析前指定机制库位置
- 所有 skill 内部引用统一为相对路径 `references/xxx.md`
- 所有参考文件均已内置，不依赖外部路径

### Phase 5 拆分

- Phase 5 拆分为 5A/5B/5C 三个独立子步骤：
  - **5A**：Game Card + 知识卡片 + Gameplay Cards（轻量级，快速完成）
  - **5B**：Mechanism Cards（最耗时，单独拆出避免超时）
  - **5C**：全局索引更新 + 品类补丁反向检查（最后执行，确保前序完成）

### 中断恢复指引

- 新增恢复指令模板：`从 Phase [N] 继续分析 [游戏名]，报告在 [路径]`
- 新增恢复前提表：明确每个 Phase 恢复时需要哪些已有报告
- 每个 Phase 落盘即持久化，中断不丢失

### 索引更新工作单

- Phase 5C 新增"索引更新工作单"填空式模板
- 将散落在 `_index.md` 7-8 个位置的手工操作归纳为"先填一张表，再按表操作"

### Phase 1.5 检索示例

- 增加杀戮尖塔2的完整 Phase 1.5 检索实例（信号提取→索引查询→深读候选→输出参考）
- 品类映射表新增 `卡牌肉鸽/卡牌构筑 → card-roguelike`

### 品类补丁反向更新提醒

- Phase 5C 完成后自动检查：品类覆盖、ADD 子模块遗漏、SKIP 准确性
- 仅输出建议提示，不自动修改 genre-patches.md

### 知识库查重（Pre-check）

- 用户触发分析时，在 Phase 0 之前自动查重（本地知识库→本地产出）
- 已有结果：展示核心结论，用户可选"查看/重新分析/补充分析"，避免重复消耗 token

### 知识库共建

- 全流程完成后询问用户是否打包回传分析结果
- 用户确认后自动打包 zip，告知通过 POPO 发送给管理员

### 安装与版本

- 新增 `install.py`：4 步引导式安装
- 所有 5 个 skill 的 YAML 头部统一添加 `version: "2.5"`
- 新增 `README.md` + `CHANGELOG.md` + `Learning.md`

---

## V2.3 — 2026-03-19

### Phase 0 玩法拓扑分析

- 新增 `gameplay-analyse.md`：识别主/副玩法，定义核心循环，分析副玩法差分
- game-analyse.md 整合 Phase 0 为 Phase 0+1 共享信息收集模式
- 新增玩法判定三条线（独立性/操作性/产出性）
- 新增副玩法关系类型判定（变体 vs 独立）

---

## V2.2 — 2026-03-18

### Phase 1 机制扫描增强

- mechanism-analyse 新增 Step 2.5：SKIP 预设机制（通用 SKIP + 品类 SKIP）
- mechanism-analyse 新增 Step 3.5：SKIP 异常检测（恢复误 SKIP 的模块）
- mechanism-analyse 新增并发分组扫描（9 组并发，组内顺序）
- 通用清单支持品类 ADD 子模块

---

## V2.1 — 2026-03-17

### Phase 5 标准化入库

- 新增 Phase 5：知识卡片、Game Card、Mechanism Card、全局索引更新
- 新增 `entry-templates.md`：Game Card 和 Mechanism Card 标准模板
- 新增 `标签标准化参考.md`：标签判定规则
- 新增 `knowledge/_index.md`：全局机制索引（倒排索引结构）

---

## V2.0 — 2026-03-15

### 全流程串联

- 新增 `game-analyse.md`：主入口串联 mechanism-analyse → mechanism-evaluate → mechanism-reason
- 定义 Phase 间数据传递规则
- 新增 Phase 1.5：知识库检索（全局索引跨品类 + 品类先验）

---

## V1.0 — 2026-03-10

### 初始版本

- mechanism-analyse：57 子模块通用清单 + 7 品类修正补丁 + 模式一/模式二
- mechanism-evaluate：品类原型词典 + 三层拆解 + 3 条创新门槛
- mechanism-reason：5 步推理链 + 协同关系图 + 承重墙识别
