# game-analyse — 游戏机制全流程分析工具

> 输入一个游戏名，自动完成从玩法拓扑到机制推理的完整分析，产出结构化的机制库入库文件。

## 安装

### 方式一：运行安装脚本（推荐）

```bash
python install.py
```

安装脚本会引导你完成：
1. 将 skill 文件安装到 `~/.codemaker/skills/`
2. 选择机制库产出目录（报告、卡片等的保存位置）
3. 自动创建产出目录结构（games/mechanisms/gameplays/reports/）
4. 生成 AGENTS.md 工作区配置

### 方式二：手动安装

```bash
# 1. 复制到 skills 目录
cp game-analyse.md gameplay-analyse.md mechanism-reason.md ~/.codemaker/skills/
cp mechanism-analyse.md ~/.codemaker/skills/mechanism-analyse/SKILL.md
cp mechanism-evaluate.md ~/.codemaker/skills/mechanism-evaluate/SKILL.md
cp -r mechanism-analyse/references ~/.codemaker/skills/mechanism-analyse/
cp -r mechanism-evaluate/references ~/.codemaker/skills/mechanism-evaluate/

# 2. 创建机制库目录（替换为你想要的路径）
mkdir -p ~/mechanism-lib/{games,mechanisms,gameplays,reports}
```

## 快速开始

### 1. 设置工作目录

告诉 agent 你的机制库在哪：

```
设置工作区位于 [你在安装时选择的目录]
```

### 2. 触发分析

```
分析《杀戮尖塔2》
```

等效触发词：`拆解 [游戏]`、`看看 [游戏]`、`研究一下 [游戏]`

### 3. 流程自动执行

| Phase | 名称 | 做什么 | 产出 |
|-------|------|--------|------|
| 0+1 | 共享搜索→玩法拓扑→机制扫描 | 5-7 组搜索，识别主/副玩法，扫描 57+N 个子模块 | `00-玩法拓扑报告.md` + `01-机制扫描报告.md` |
| 1.5 | 知识库检索 | 在已有机制库中查找跨品类参考 | （内部传递，不落盘） |
| 2 | 创新评价 | 识别品类原型，判断结构创新 vs 品类标配 | `02-创新评价卡片.md` |
| 3 | 机制推理 | 推理因果关系，识别体验支柱和承重墙 | `03-机制推理报告.md` |
| 5 | 标准化入库 | 生成 Game Card / Mechanism Cards / Gameplay Cards / 更新索引 | 多个入库文件 |
| 4（可选） | 单机制深挖 | 对特定机制做 6 步推理链 | `04-[机制名]-深析报告.md` |

### 4. 中断与恢复

可以在任何 Phase 完成后暂停：
- `先到这里` → 停止，已有报告已落盘
- `继续` → 从下一个 Phase 继续
- `从 Phase 2 继续分析 [游戏名]，报告在 [路径]` → 跳过已完成的 Phase

---

## 配套文档

| 文档 | 用途 |
|------|------|
| `README.md` | 本文件。安装方法、快速入门、文件结构说明 |
| `Learning.md` | **方法论指南**。解释"为什么这样分析"——扫描/评价/推理三阶段的设计理念、品类原型思维、结构创新的判断逻辑。不讲操作步骤，只讲思考方式。建议首次使用前通读 |
| `CHANGELOG.md` | **版本迭代记录**。记录每个版本的功能变更，便于了解当前版本能力和历史演进 |
| `example/` | **示例产出**。杀戮尖塔2的完整分析产出（12个文件），包含 Phase 0-3 报告 + Game Card + 5张 Mechanism Card + 2张 Gameplay Card。安装前可先浏览，了解工具会产出什么 |

---

## Skill 文件结构

```
~/.codemaker/skills/
├── game-analyse.md              # 主入口（编排所有 Phase）
├── gameplay-analyse.md          # Phase 0：玩法拓扑分析
├── mechanism-reason.md          # Phase 3：机制推理
├── mechanism-analyse/
│   ├── SKILL.md                 # Phase 1：机制扫描
│   └── references/              # 所有参考文件（随 skill 分发）
│       ├── universal-checklist.md      # 57 子模块通用清单
│       ├── genre-patches.md            # 7 品类修正补丁
│       ├── entry-templates.md          # 入库模板（Game/Mechanism/Gameplay Card）
│       ├── 标签标准化参考.md              # 标签判定规则
│       └── knowledge/                  # 机制知识库
│           ├── _index.md               # 全局索引（倒排索引）
│           ├── _template.md            # 知识卡片模板
│           └── [品类]/                 # 按品类分组的知识卡片
└── mechanism-evaluate/
    ├── SKILL.md                 # Phase 2：创新评价
    └── references/
        └── genre-archetype-dictionary.md  # 品类原型词典
```

## 产出目录结构

```
${MECHANISM_LIB}/                # 用户指定的机制库根目录
├── reports/[GameName]/          # 过程报告（4 份）
├── games/[GameName].md          # Game Card（1 张）
├── mechanisms/[GameName]/       # Mechanism Cards（N 张）
├── gameplays/[GameName]/        # Gameplay Cards（1+N 张）
└── ...
```

---

## 路径约定

- `${MECHANISM_LIB}`：机制库根目录，由用户在分析前指定
- `references/`：指 `mechanism-analyse/references/`，即 skill 内置参考文件，随 skill 打包分发，不依赖外部路径
- 所有参考文件均已内置，安装 skill 后即可使用，无需额外配置

---

## 单独使用子 Skill

正常情况下只需要通过 `game-analyse`（主入口）触发。以下场景可单独使用子 skill：

| 场景 | 触发词 | 调用的 skill |
|------|--------|-------------|
| 只扫描机制 | "只扫描 [游戏] 的机制" | mechanism-analyse |
| 只评价创新 | "评价这份扫描报告" | mechanism-evaluate |
| 只推理协同 | "推理 [游戏] 的机制逻辑" | mechanism-reason |
| 只分析玩法 | "[游戏] 有哪些玩法" | gameplay-analyse |

---

## 已分析游戏

截至 V2.5，知识库中已收录：

- **41 张机制卡** | **15 款游戏** | **5 个品类**
- 品类覆盖：模拟经营、生活模拟、自动化、生存、休闲、城建、农场经营、FPS/搜打撤、卡牌肉鸽

查看完整索引：`references/knowledge/_index.md`

---

## 知识库共建

这套工具支持团队协作共建机制知识库：

- **你的分析会沉淀**：每次分析的结构创新、体验支柱、协同关系会自动写入本地知识库
- **节省 token**：下次分析同品类游戏时，知识库自动提供已拆解游戏的参考基线，不需要从零开始
- **共享给团队**：分析完成后会询问是否打包回传。通过 POPO 发送给管理员审核入库后，后续所有人都能查到
