# 示例产出 — 杀戮尖塔2（Slay the Spire 2）

> 这是一次完整的 game-analyse 全流程分析的真实产出。你可以通过这些文件了解每个 Phase 会生成什么、格式长什么样。

## 文件清单

### 过程报告（Phase 0-3）

| 文件 | Phase | 说明 |
|------|-------|------|
| `reports/00-玩法拓扑报告.md` | Phase 0 | 识别主/副玩法：单人爬塔 + 4人合作爬塔 |
| `reports/01-机制扫描报告.md` | Phase 1 | 5大机制模块扫描，覆盖57+子模块 |
| `reports/02-创新评价卡片.md` | Phase 2 | 品类原型识别 + 结构创新判定（4项Excellent + 1项Qualify） |
| `reports/03-机制推理报告.md` | Phase 3 | 因果链推理 + 承重墙识别 + 体验支柱分析 |

### 入库文件（Phase 5 自动生成）

| 文件 | 类型 | 说明 |
|------|------|------|
| `games/SlayTheSpire2.md` | Game Card | 游戏总览卡：X-Statement、核心判断、体验支柱、承重墙、Top 5机制 |
| `mechanisms/[Excellent]Roguelike-SlayTheSpire2-附魔改造系统.md` | Mechanism Card | 牌组构筑第四维度 |
| `mechanisms/[Excellent]Roguelike-SlayTheSpire2-跨幕投资任务.md` | Mechanism Card | 跨阶段投资决策机制 |
| `mechanisms/[Excellent]Roguelike-SlayTheSpire2-合作爬塔模式.md` | Mechanism Card | 品类首创的4人合作PvE |
| `mechanisms/[Excellent]Roguelike-SlayTheSpire2-动态AI反制.md` | Mechanism Card | 打破 Block is King 的动态意图系统 |
| `mechanisms/[Qualify]Roguelike-SlayTheSpire2-遗物升级与耐久.md` | Mechanism Card | 营火决策扩展 |
| `gameplays/主玩法-单人爬塔.md` | Gameplay Card | 核心循环：单人卡牌构筑肉鸽 |
| `gameplays/副玩法-4人合作爬塔.md` | Gameplay Card | 副循环：合作社交策略层 |

## 目录结构对应关系

```
example/                         ←  对应你的 ${MECHANISM_LIB}/
├── reports/                     ←  ${MECHANISM_LIB}/reports/SlayTheSpire2/
│   ├── 00-玩法拓扑报告.md
│   ├── 01-机制扫描报告.md
│   ├── 02-创新评价卡片.md
│   └── 03-机制推理报告.md
├── games/                       ←  ${MECHANISM_LIB}/games/
│   └── SlayTheSpire2.md
├── mechanisms/                  ←  ${MECHANISM_LIB}/mechanisms/SlayTheSpire2/
│   ├── [Excellent]...-附魔改造系统.md
│   ├── [Excellent]...-跨幕投资任务.md
│   ├── [Excellent]...-合作爬塔模式.md
│   ├── [Excellent]...-动态AI反制.md
│   └── [Qualify]...-遗物升级与耐久.md
└── gameplays/                   ←  ${MECHANISM_LIB}/gameplays/SlayTheSpire2/
    ├── 主玩法-单人爬塔.md
    └── 副玩法-4人合作爬塔.md
```

> 实际使用时，reports/mechanisms/gameplays 下会按游戏名建子文件夹（如 `SlayTheSpire2/`）。这里为了示例简洁做了扁平化。
