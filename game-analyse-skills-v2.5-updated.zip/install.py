"""
game-analyse V2.5 安装脚本

使用方式：
    python install.py

功能：
1. 将 skill 文件安装到 ~/.codemaker/skills/
2. 询问用户的机制库产出目录（${MECHANISM_LIB}）
3. 自动创建产出目录结构
4. 生成 AGENTS.md 工作区配置
"""

import os
import platform
import shutil
import sys
import textwrap

# ─── 路径计算 ───

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

if platform.system() == "Windows":
    SKILLS_DIR = os.path.join(os.path.expanduser("~"), ".codemaker", "skills")
else:
    SKILLS_DIR = os.path.expanduser("~/.codemaker/skills")


# ─── 需要安装的文件映射 ───

# (源文件相对于 SCRIPT_DIR, 目标相对于 SKILLS_DIR)
SKILL_FILES = [
    # 主入口
    ("game-analyse.md", "game-analyse.md"),
    ("gameplay-analyse.md", "gameplay-analyse.md"),
    ("mechanism-reason.md", "mechanism-reason.md"),
    # mechanism-analyse（目录型 skill）
    ("mechanism-analyse.md", os.path.join("mechanism-analyse", "SKILL.md")),
    # mechanism-evaluate（目录型 skill）
    ("mechanism-evaluate.md", os.path.join("mechanism-evaluate", "SKILL.md")),
]

# 需要整目录复制的 references
REFERENCE_DIRS = [
    (os.path.join("mechanism-analyse", "references"),
     os.path.join("mechanism-analyse", "references")),
    (os.path.join("mechanism-evaluate", "references"),
     os.path.join("mechanism-evaluate", "references")),
]

# 产出目录结构
OUTPUT_DIRS = [
    "games",
    "mechanisms",
    "gameplays",
    "reports",
]


# ─── 工具函数 ───

def print_header(text):
    print(f"\n{'=' * 60}")
    print(f"  {text}")
    print(f"{'=' * 60}\n")


def print_step(n, total, text):
    print(f"  [{n}/{total}] {text}")


def ask_path(prompt, default):
    """询问路径，支持默认值。"""
    if default:
        user_input = input(f"  {prompt} [{default}]: ").strip()
        return user_input if user_input else default
    else:
        while True:
            user_input = input(f"  {prompt}: ").strip()
            if user_input:
                return user_input
            print("  ⚠ 路径不能为空，请重新输入。")


def copy_file_safe(src, dst):
    """复制文件，如果目标已存在且内容不同则提示。"""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isfile(dst):
        # 比较内容
        with open(src, "rb") as f1, open(dst, "rb") as f2:
            if f1.read() == f2.read():
                return "skip"  # 完全相同，跳过
        return "update"  # 内容不同，需要更新
    shutil.copy2(src, dst)
    return "new"


def copy_dir_safe(src, dst):
    """复制目录，跳过已存在且内容相同的文件。"""
    stats = {"new": 0, "update": 0, "skip": 0}
    for root, dirs, files in os.walk(src):
        for f in files:
            s = os.path.join(root, f)
            rel = os.path.relpath(s, src)
            d = os.path.join(dst, rel)
            result = copy_file_safe(s, d)
            if result == "new":
                shutil.copy2(s, d)
                stats["new"] += 1
            elif result == "update":
                shutil.copy2(s, d)
                stats["update"] += 1
            else:
                stats["skip"] += 1
    return stats


# ─── 主流程 ───

def main():
    print_header("game-analyse V2.5 安装向导")

    total_steps = 4

    # ─── Step 1: 确认 skill 安装位置 ───
    print_step(1, total_steps, "确认 skill 安装位置")
    print(f"  Skills 目录: {SKILLS_DIR}")

    if not os.path.isdir(SKILLS_DIR):
        print(f"  目录不存在，将自动创建。")
        os.makedirs(SKILLS_DIR, exist_ok=True)
    print()

    # ─── Step 2: 询问机制库产出目录 ───
    print_step(2, total_steps, "设置机制库产出目录")
    print()
    print(textwrap.dedent("""\
      分析游戏时产出的报告、Game Card、Mechanism Card 等文件
      会保存到这个目录。你可以选择任何有写入权限的位置。

      目录结构将自动创建：
        [你的目录]/
        ├── games/          # Game Card
        ├── mechanisms/     # Mechanism Card
        ├── gameplays/      # Gameplay Card
        └── reports/        # 过程报告
    """))

    # 默认值
    if platform.system() == "Windows":
        default_lib = r"D:\mechanism-lib"
    else:
        default_lib = os.path.expanduser("~/mechanism-lib")

    mechanism_lib = ask_path("请输入机制库目录路径", default_lib)
    mechanism_lib = os.path.abspath(mechanism_lib)
    print(f"\n  ✓ 机制库目录: {mechanism_lib}\n")

    # ─── Step 3: 安装 skill 文件 ───
    print_step(3, total_steps, "安装 skill 文件")

    # 安装单文件 skills
    for src_rel, dst_rel in SKILL_FILES:
        src = os.path.join(SCRIPT_DIR, src_rel)
        dst = os.path.join(SKILLS_DIR, dst_rel)
        if not os.path.isfile(src):
            print(f"  ⚠ 跳过（源文件不存在）: {src_rel}")
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        print(f"  ✓ {dst_rel}")

    # 安装 references 目录
    for src_rel, dst_rel in REFERENCE_DIRS:
        src = os.path.join(SCRIPT_DIR, src_rel)
        dst = os.path.join(SKILLS_DIR, dst_rel)
        if not os.path.isdir(src):
            print(f"  ⚠ 跳过（源目录不存在）: {src_rel}")
            continue
        stats = copy_dir_safe(src, dst)
        print(f"  ✓ {dst_rel}/ ({stats['new']} new, {stats['update']} updated, {stats['skip']} unchanged)")

    print()

    # ─── Step 4: 创建产出目录结构 + AGENTS.md ───
    print_step(4, total_steps, "初始化机制库目录")

    for d in OUTPUT_DIRS:
        full = os.path.join(mechanism_lib, d)
        os.makedirs(full, exist_ok=True)
        print(f"  ✓ {d}/")

    # 生成 AGENTS.md（如果不存在则创建，已存在则跳过）
    agents_path = os.path.join(mechanism_lib, "AGENTS.md")
    if not os.path.isfile(agents_path):
        agents_content = textwrap.dedent(f"""\
            # GAC - Game Analyse Consultant (V2.5)

            GAC（Game Analyse Consultant）是游戏测评工程师 Agent，专注于游戏机制的系统性分析。

            ## 身份

            你是一个资深游戏测评工程师。你的工作是用结构化的方法拆解任意游戏的机制设计，评价其创新程度，并推理机制间的因果关系和协同结构。

            你的工作区在 `{mechanism_lib}`，所有分析工具和参考资料都在这个目录下。

            ## 快速开始

            1. 设置工作区：告诉 AI "设置工作区位于 {mechanism_lib}"
            2. 触发分析：说 "分析《游戏名》"
            3. 等待全流程自动执行（Phase 0→1→1.5→2→3→5）

            ## 核心工具集

            | Skill | 用途 | 触发方式 |
            |-------|------|---------|
            | **game-analyse** | 全流程分析（默认入口） | "分析 [游戏]" |
            | gameplay-analyse | 玩法拓扑分析 | "这个游戏有哪些玩法" |
            | mechanism-analyse | 机制扫描 / 深析 | "只扫描"、"深析 [机制]" |
            | mechanism-evaluate | 创新评价 | "评价这份报告" |
            | mechanism-reason | 机制推理 | "只做机制推理" |

            ## 工作流

            ```
            "分析 [游戏名]"
              ├─ Phase 0+1: 玩法拓扑 + 机制扫描
              ├─ Phase 1.5: 知识库检索（自动）
              ├─ Phase 2: 创新评价
              ├─ Phase 3: 机制推理
              ├─ Phase 5: 标准化入库（自动）
              └─ Phase 4: 单机制深挖（可选）
            ```

            ## 产出目录

            ```
            {mechanism_lib}/
            ├── games/          # Game Card
            ├── mechanisms/     # Mechanism Card（按游戏分文件夹）
            ├── gameplays/      # Gameplay Card（按游戏分文件夹）
            ├── reports/        # 过程报告（按游戏分文件夹）
            └── AGENTS.md       # 本文件
            ```

            ## 语气风格

            - 直接、锋利、可用于讨论会
            - 先给核心判断，再展开证据
            - 不铺垫、不客套、不空洞评价
        """)
        with open(agents_path, "w", encoding="utf-8") as f:
            f.write(agents_content)
        print(f"  ✓ AGENTS.md（新建）")
    else:
        print(f"  - AGENTS.md（已存在，跳过）")

    # ─── 完成 ───
    print_header("安装完成！")
    print(textwrap.dedent(f"""\
      Skill 已安装到:  {SKILLS_DIR}
      机制库目录:      {mechanism_lib}

      开始使用:
        1. 打开 AI 对话
        2. 说: "设置工作区位于 {mechanism_lib}"
        3. 说: "分析《黑神话悟空》"

      更多信息请查看:
        - README.md     — 使用说明
        - CHANGELOG.md  — 版本记录
    """))


if __name__ == "__main__":
    main()
